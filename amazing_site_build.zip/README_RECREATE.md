# ROCK.SCOT | RECREATION MANIFEST
## BUILD: CARSON GRUNGE v2.5 (2026-01-21)

### 1. DESIGN PHILOSOPHY
- **Lead Designer Style:** David Carson (Godfather of Grunge).
- **Visual Rules:** Chaos over order, overlapping textures, "scrap paper" UI elements.
- **Color Palette:** - Black (#000)
  - Authority Orange (#ff5500)
  - Acid Green (#a2ff00)
- **Safety Margins:** 95% background scaling rule for Sony Xperia/Mobile compatibility.

### 2. CORE DIRECTORY STRUCTURE
/ (Root)
├── index.html (Main SPA structure)
├── style.css (Grunge filters, 95% BG rule, animations)
├── README_RECREATE.md
├── js/
│   ├── core.js (Stream logic & Global app state)
│   ├── wire.js (RSS News with Master/Skinny fallback)
│   ├── crew.js (Fanzine Dossier system for 8 DJs)
│   └── ads.js (Swiss-Bank math engine / pro-rata formula)
└── assets/
    ├── branding/
    │   ├── logo.png (120% ultra-wide logo)
    │   └── logo_ultra_wide.png
    ├── backgrounds/
    │   └── background1.jpg through background7.jpg
    └── crew/
        └── dj_andy.jpg, dj_alex.jpg, etc.

### 3. TECHNICAL LOGIC
- **Commercial Math:** (Price / 28 * Days) * 1.3 surcharge if days < 27.
- **Wire Redundancy:** Master Feed (Music-News) -> Fallback (Skinny RSS).
- **Pathing:** Strictly relative (./) for GitHub Pages subdirectory compatibility.

### 4. RECREATION STEPS
1. Host on GitHub Pages at /Sla-rock.scot/
2. Ensure folder names are lowercase (case-sensitive).
3. Clear browser cache on mobile to bypass PWA/Service Worker caching.
