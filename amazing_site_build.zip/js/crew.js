window.crewApp = {
    index: 0,
    members: [
        { name: "ANDY", loc: "EAST KILBRIDE", bio: "EK REBEL. RAISED ON BIFFY CLYRO. HIGH-ENERGY BROADCAST PROTOCOL.", fav: "BIFFY CLYRO", gig: "FRANZ FERDINAND @ B-LANDS", dream: "KING TUT'S", fun: "LOST A SHOE IN HAMILTON." },
        { name: "ALEX", loc: "JOHNSTONE", bio: "VINYL VIKING. NAZARETH SPECIALIST. PAISLEY GIG CIRCUIT VETERAN.", fav: "NAZARETH", gig: "TEXAS @ ARMADILLO", dream: "BARROWLANDS", fun: "SIGNED DEACON BLUE VINYL." },
        { name: "STEVIE", loc: "PORT GLASGOW", bio: "PORT HEADBANGER. RAISED ON AC/DC. INVERCLYDE AUTHORITY.", fav: "BIG COUNTRY", gig: "MOGWAI @ ORAN MOR", dream: "BEACON ARTS", fun: "HIGH-FIVED ANGUS YOUNG." },
        { name: "MHAIRI", loc: "HAMILTON", bio: "HARD ROCK QUEEN. DISTORTION OBSESSED. TATTOO ARTIST.", fav: "JESUS/MARY CHAIN", gig: "TEENAGE FANCLUB @ TUT'S", dream: "GRAND HALL", fun: "SPECIALIZES IN BAND LOGOS." },
        { name: "JUDE", loc: "IRVINE", bio: "INDIE ICON. NORTH AYRSHIRE STOMPING GROUND. TRAVIS INFLUENCED.", fav: "TRAVIS", gig: "IDLEWILD @ B-LANDS", dream: "HARBOUR ARTS", fun: "HITCHHIKED TO GLASGOW." },
        { name: "CHRIS", loc: "GREENOCK", bio: "GUITAR GURU. SHIPYARD ROCK SPECIALIST. PRIMAL SCREAM DISCIPLE.", fav: "PRIMAL SCREAM", gig: "SIMPLE MINDS @ HYDRO", dream: "CATHOUSE", fun: "BIG COUNTRY VINYL ARCHIVE." },
        { name: "CAL", loc: "KILMARNOCK", bio: "CLASSIC ROCKER. BIFFY CLYRO LOCAL. AIR GUITAR CHAMP.", fav: "BIFFY CLYRO", gig: "FRATELLIS @ GRAND HALL", dream: "PALACE THEATRE", fun: "WON KILLIE AIR GUITAR." },
        { name: "BLUE", loc: "GOUROCK", bio: "BLUESY MAVERICK. COASTAL ROCK ENERGY. GOUROCK TO WEMYSS BAY.", fav: "NAZARETH", gig: "TEXAS @ PAISLEY", dream: "COATS PAISLEY", fun: "MISTAKEN FOR ROADIE." }
    ],
    init: function() {
        const stage = document.getElementById('crew-stage');
        stage.innerHTML = `
            <div class="fanzine-wrap">
                <div class="photo-rip">
                    <img id="active-dj-img" src="" style="width:100%; filter: contrast(150%) grayscale(100%);">
                    <div class="tape-label" id="dj-name-sticker">ANDY</div>
                </div>
                <div class="bio-scrap">
                    <h3 class="scrap-title">STATION DATA //</h3>
                    <p id="dj-bio" class="marker-text"></p>
                    <ul class="stats-list">
                        <li>BASE: <span id="dj-loc"></span></li>
                        <li>FAV: <span id="dj-fav"></span></li>
                        <li>BEST: <span id="dj-gig"></span></li>
                        <li>FACT: <span id="dj-fun"></span></li>
                    </ul>
                </div>
            </div>
        `;
        this.render(0);
    },
    render: function(i) {
        const m = this.members[i];
        document.getElementById('active-dj-img').src = `./assets/crew/dj_${m.name.toLowerCase()}.jpg`;
        document.getElementById('dj-name-sticker').innerText = m.name;
        document.getElementById('dj-bio').innerText = m.bio;
        document.getElementById('dj-loc').innerText = m.loc;
        document.getElementById('dj-fav').innerText = m.fav;
        document.getElementById('dj-gig').innerText = m.gig;
        document.getElementById('dj-fun').innerText = m.fun;
        this.index = i;
    },
    next: function() { this.index = (this.index + 1) % this.members.length; this.render(this.index); },
    prev: function() { this.index = (this.index - 1 + this.members.length) % this.members.length; this.render(this.index); }
};
