window.app = {
    init: function() {
        this.startClock();
        if(localStorage.getItem('cookies_accepted')) {
            document.getElementById('legal-master-wrap').style.display = 'none';
        }
    },
    startClock: function() {
        setInterval(() => {
            const el = document.getElementById('clock');
            if(el) {
                const now = new Date();
                el.innerText = now.toLocaleTimeString('en-GB', { hour12: false });
            }
        }, 1000);
    },
    toggleStream: function() {
        const audio = document.getElementById('main-stream');
        const btn = document.getElementById('play-btn');
        const status = document.getElementById('player-status');
        
        if (audio.paused) {
            audio.play().then(() => {
                btn.innerText = "STOP STREAM";
                status.innerText = "STREAMING LIVE";
                status.style.color = "var(--rock-orange)";
            }).catch(e => {
                console.error("Stream Blocked", e);
                alert("Please tap again to allow audio playback.");
            });
        } else {
            audio.pause();
            btn.innerText = "LISTEN LIVE";
            status.innerText = "ON AIR";
            status.style.color = "#fff";
        }
    },
    switchTab: function(id) {
        document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
        document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
        
        document.getElementById('v-' + id).classList.add('active');
        const btn = document.querySelector(`[onclick*="'${id}'"]`);
        if(btn) btn.classList.add('active');

        if(id === 'wire') wireApp.load();
        if(id === 'crew') crewApp.init();
        if(id === 'rates') adsApp.init();
    },
    acceptCookies: function() {
        document.getElementById('legal-master-wrap').style.display = 'none';
        localStorage.setItem('cookies_accepted', 'true');
    }
};
document.addEventListener('DOMContentLoaded', () => app.init());
