window.wireApp = {
    masterFeed: 'https://www.music-news.com/rss/UK/news',
    skinnyFeed: 'https://rss.app/feeds/v1/6pY8iR4uYx7j5s2G.xml', // Emergency Backup
    load: function() {
        const grid = document.getElementById('wire-grid');
        grid.innerHTML = '<p>Syncing News Feeds...</p>';
        this.fetch(this.masterFeed, true);
    },
    fetch: function(url, isMaster) {
        const grid = document.getElementById('wire-grid');
        // Using a more reliable CORS proxy
        fetch(`https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(url)}`)
        .then(res => res.json())
        .then(data => {
            if (data.status !== 'ok' || !data.items.length) throw new Error();
            grid.innerHTML = data.items.map(item => `
                <div class="uniform-card" style="margin-bottom:15px; text-align:left;">
                    <h4 style="color:var(--rock-orange); margin:0;">${item.title}</h4>
                    <p style="font-size:0.75rem; color:#ccc;">${item.description.replace(/<[^>]*>/g, '').substring(0, 120)}...</p>
                    <a href="${item.link}" target="_blank" style="color:var(--rock-orange); font-size:0.7rem; font-weight:bold;">READ FULL STORY</a>
                </div>
            `).join('');
        })
        .catch(() => {
            if (isMaster) {
                console.warn("Master Wire failed. Switching to Skinny Emergency Feed.");
                this.fetch(this.skinnyFeed, false);
            } else {
                grid.innerHTML = '<div class="uniform-card"><h3>WIRE OFFLINE</h3><p>Could not connect to news servers. Check back shortly.</p></div>';
            }
        });
    }
};
