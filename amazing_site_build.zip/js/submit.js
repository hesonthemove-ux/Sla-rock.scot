window.submitApp = {
    send: function() {
        const band = document.getElementById('sub-band').value;
        const link = document.getElementById('sub-link').value;
        if(!band || !link) return alert("Please provide Band Name and Track Link.");
        
        alert("Success! " + band + " submission received via secure portal.");
        // Logic for backend post would go here
    }
};
