window.adsApp = {
    init: function() {
        const container = document.getElementById('v-rates');
        container.innerHTML = `
            <div class="fanzine-wrap ad-portal">
                <div class="bio-scrap ad-card" style="transform: rotate(-1deg); width: 100%; margin-top: 0;">
                    <h3 class="scrap-title" style="font-size: 2rem;">RATE CARD // 2026</h3>
                    <p class="marker-text">CENTRAL SCOTLAND ADVERTISING PROTOCOL</p>
                    
                    <div style="margin: 20px 0;">
                        <label class="ad-label">01 CLIENT NAME</label>
                        <input type="text" id="ad-name" class="raw-input" placeholder="REQUIRED">
                        
                        <label class="ad-label">02 POSTCODE / LOCATION</label>
                        <div style="display:flex; gap:10px;">
                            <input type="text" id="ad-post" class="raw-input" style="flex:2;">
                            <button onclick="adsApp.lookupPostcode()" class="tape-btn">FIND</button>
                        </div>
                        <input type="text" id="ad-addr" class="raw-input" placeholder="ADDRESS DATA" style="margin-top:5px;">
                    </div>

                    <div style="background:#000; color:#fff; padding:15px; transform: rotate(1deg); margin: 20px -10px;">
                        <label style="font-size:0.7rem; font-weight:900;">03 CAMPAIGN WINDOW</label>
                        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:10px; margin-top:5px;">
                            <input type="date" id="ad-start" onchange="adsApp.calc()" class="dark-input">
                            <input type="date" id="ad-end" onchange="adsApp.calc()" class="dark-input">
                        </div>
                    </div>

                    <label class="ad-label">04 PACKAGE SELECT</label>
                    <select id="ad-tier" onchange="adsApp.calc()" class="raw-input" style="font-weight:900;">
                        <option value="299">REGIONAL AIRTIME (£299)</option>
                        <option value="449">MULTI-REGIONAL (£449)</option>
                        <option value="195">CREATIVE SERVICES (£195)</option>
                    </select>

                    <div id="ad-calc-box" style="margin-top:20px; border-top: 4px solid #000; padding-top:15px;">
                        <div style="display:flex; justify-content:space-between; font-weight:900;">
                            <span>DAYS:</span> <span id="ad-days">0</span>
                        </div>
                        <div id="ad-surcharge" style="background:var(--rock-orange); color:#fff; padding:5px; font-size:0.7rem; margin:10px 0; display:none; text-align:center; font-weight:900;">
                            SHORT-RUN SURCHARGE (1.3x) APPLIED
                        </div>
                        <div style="display:flex; justify-content:space-between; font-size:2rem; font-weight:900; color:var(--rock-orange);">
                            <span>TOTAL:</span> <span id="ad-total">£0.00</span>
                        </div>
                    </div>
                    
                    <button class="vignelli-btn" style="background:#000; color:#fff; margin-top:20px;" onclick="alert('TRANSMITTING...')">SEND INQUIRY</button>
                </div>
            </div>`;
    },
    lookupPostcode: function() {
        const pc = document.getElementById('ad-post').value;
        if(!pc) return;
        document.getElementById('ad-addr').value = "SEARCHING REGISTRY...";
        setTimeout(() => { document.getElementById('ad-addr').value = "CONFIRMED: " + pc.toUpperCase(); }, 600);
    },
    calc: function() {
        const start = new Date(document.getElementById('ad-start').value);
        const end = new Date(document.getElementById('ad-end').value);
        const pkgPrice = parseFloat(document.getElementById('ad-tier').value);
        
        if(start && end && !isNaN(start.getTime()) && !isNaN(end.getTime())) {
            const days = Math.ceil((end - start) / (1000 * 3600 * 24)) + 1;
            if(days <= 0) return;

            const dailyRate = pkgPrice / 28;
            let total = dailyRate * days;
            
            document.getElementById('ad-days').innerText = days;
            if(days < 27) {
                total = total * 1.3;
                document.getElementById('ad-surcharge').style.display = 'block';
            } else {
                document.getElementById('ad-surcharge').style.display = 'none';
            }
            document.getElementById('ad-total').innerText = "£" + total.toFixed(2);
        }
    }
};
