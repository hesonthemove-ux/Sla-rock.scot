window.adminApp = {
    masterPin: "1234",
    enteredPin: "",
    init: function() {
        this.loadMainControls();
        this.loadPriceManager();
    },
    loadMainControls: function() {
        document.getElementById('adm-reg').value = localStorage.getItem('price_reg') || 299;
        document.getElementById('adm-multi').value = localStorage.getItem('price_multi') || 449;
        document.getElementById('adm-tint').value = localStorage.getItem('glass_tint') || 0.5;
        document.getElementById('adm-ticker').value = localStorage.getItem('rock_status') || "CENTRAL SCOTLAND'S ROCK AUTHORITY";
    },
    loadPriceManager: function() {
        const grid = document.querySelector('.admin-grid');
        let pm = document.getElementById('price-manager-sec');
        if(!pm) {
            pm = document.createElement('div');
            pm.id = "price-manager-sec";
            pm.className = "admin-sec";
            pm.style.gridColumn = "1 / -1";
            pm.style.marginTop = "20px";
            pm.style.borderTop = "1px solid #333";
            pm.style.paddingTop = "20px";
            grid.appendChild(pm);
        }
        pm.innerHTML = `
            <h3 style="color:#ff5500;">SCHEDULED PRICING MANAGER</h3>
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:15px;">
                <label>Target Reg (£): <input type="number" id="p-reg" value="299"></label>
                <label>Target Multi (£): <input type="number" id="p-multi" value="449"></label>
                <label>Creative Fee (£): <input type="number" id="p-crea" value="195"></label>
                <label>Surcharge (%): <input type="number" id="p-sur" value="30"></label>
            </div>
            <label>GO-LIVE DATE (Future Only):</label>
            <input type="date" id="p-live" style="width:100%; margin-bottom:10px; background:#222; border:1px solid #444; color:#fff; padding:10px;">
            <button onclick="adminApp.schedulePrice()" style="width:100%; background:#444; color:#fff; border:none; padding:12px; cursor:pointer;">SCHEDULE AUTO-UPDATE</button>
        `;
    },
    openChallenge: function() {
        this.enteredPin = "";
        document.getElementById('pin-input').value = "";
        app.switchTab('pin');
    },
    typePin: function(n) {
        this.enteredPin += n;
        document.getElementById('pin-input').value = "*".repeat(this.enteredPin.length);
        if(this.enteredPin.length === 4) {
            if(this.enteredPin === this.masterPin) { app.switchTab('admin'); this.init(); }
            else { alert("DENIED"); this.enteredPin = ""; document.getElementById('pin-input').value = ""; }
        }
    },
    schedulePrice: function() {
        const liveDate = new Date(document.getElementById('p-live').value);
        if (!liveDate || liveDate <= new Date()) return alert("Date must be in the future.");
        const config = {
            reg: document.getElementById('p-reg').value,
            multi: document.getElementById('p-multi').value,
            creative: document.getElementById('p-crea').value,
            surcharge: document.getElementById('p-sur').value,
            live: document.getElementById('p-live').value
        };
        localStorage.setItem('scheduled_pricing', JSON.stringify(config));
        alert("Pricing change scheduled for " + config.live);
    },
    updateTint: function(val) {
        document.documentElement.style.setProperty('--glass-tint', val);
        localStorage.setItem('glass_tint', val);
    },
    saveAll: function() {
        localStorage.setItem('price_reg', document.getElementById('adm-reg').value);
        localStorage.setItem('price_multi', document.getElementById('adm-multi').value);
        localStorage.setItem('rock_status', document.

cd ~/storage/shared/Geminibuild

# Inject Schema into the <head> of index.html
sed -i '/<title>/a \
    <script type="application/ld+json">\
    {\
      "@context": "https://schema.org",\
      "@type": "RadioStation",\
      "name": "Rock.Scot",\
      "url": "https://rock.scot",\
      "logo": "https://rock.scot/assets/logo_ultra_wide.png",\
      "description": "Central Scotland'\''s Rock Authority. Local news, music feeds, and the best rock for the region.",\
      "address": {\
        "@type": "PostalAddress",\
        "addressRegion": "Central Scotland",\
        "addressCountry": "GB"\
      },\
      "geo": {\
        "@type": "GeoCoordinates",\
        "latitude": "55.8642",\
        "longitude": "-4.2518"\
      },\
      "hasBroadcastService": {\
        "@type": "BroadcastService",\
        "name": "Rock.Scot Live Feed",\
        "broadcastFrequency": "Digital/Online"\
      }\
    }\
    </script>' index.html

git add .
git commit -m "SEO Build: Added JSON-LD Schema for RadioStation and Local Authority metadata."
git push -u origin main --force

cd ~/storage/shared/Geminibuild

# 1. Inject Apple-specific PWA tags and Theme colors into index.html
sed -i '/<link rel="manifest"/a \
    <meta name="apple-mobile-web-app-capable" content="yes">\
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">\
    <meta name="apple-mobile-web-app-title" content="Rock.Scot">\
    <link rel="apple-touch-icon" href="assets/logo_ultra_wide.png">\
    <meta name="theme-color" content="#ff5500">' index.html

# 2. Add a 'Sitemap' and 'Robots.txt' for complete professional indexing
cat << 'EOF' > robots.txt
User-agent: *
Allow: /
Sitemap: https://rock.scot/sitemap.xml
