# Rock.Scot | Central Scotland's Rock Authority
**Version:** 1.5 (Secure Master Build)
**Last Updated:** 2026-01-20

## 📡 Platform Overview
Rock.Scot is a high-authority Single Page Application (SPA) designed for Central Scotland's premier rock station. It is engineered for the Sony Xperia 5 V (21:9 aspect ratio) with high-fidelity 3D transitions and a custom commercial pricing engine.

---

## 🛠 Features & Functionality by Page

### 1. Live (Home)
* **Broadcast Integration:** Features a low-latency iframe player for the Caledonia TX feed.
* **Studio Clock:** High-end "Gucci Neon" clock with tabular-num alignment and orange glow effect.
* **Branding:** 130% ultra-wide logo scaling, utilizing the full width of the header.

### 2. The Wire (News)
* **Content:** Aggregates music and local news relevant to Central Scotland.
* **UI:** Dynamic grid layout with thumbnail support and source-toggle controls.

### 3. The Crew (DJs)
* **3D Carousel:** A high-end "Rolodex" style gallery using Z-axis depth and Y-axis rotation.
* **Touch-Swipe:** Native gesture support for Xperia/Mobile users to flick through talent.
* **Focus Logic:** The center DJ is displayed in full color while peripheral cards fade to grayscale.

### 4. Rates (Commercial)
* **Pricing Intelligence:** * **Regional:** £299
    * **Multi-Regional:** £449
    * **Creative/Production:** £195 (One-time fee)
* **Short-Run Surcharge:** Automatic 30% surcharge applied to any campaign duration ≤ 27 days.
* **Compatibility:** Includes a responsive data capture form for lead generation.

### 5. Master Control (Admin) - HIDDEN
* **Access:** Triggered by a **Double-Tap** on the Header Logo.
* **Security:** Protected by a 4-digit **Security PIN** (Default: 1234) via a glassmorphism keypad.
* **Controls:** * Live Pricing Updates (Updates the Rates page instantly).
    * UI Glass Tint slider (Adjusts transparency levels globally).
    * Live Ticker News Editor (Updates the scrolling announcement).

---

## 🎨 Visual Rules & CSS Standards
* **Mobile Framing:** Background images are hard-locked to **90% scale** on mobile to create a premium framed look.
* **Gradient Smoothing:** A bottom-to-black linear gradient is applied to background images to ensure text legibility and a smooth transition into the UI.
* **Width Exclusion:** The Header, Navigation, and Ticker are excluded from the 90% rule, spanning the full **100vw** of the handset.

## 📂 File Structure
* `index.html`: SPA Controller and View Containers.
* `style.css`: 3D Physics, Glassmorphism, and Responsive Overrides.
* `js/core.js`: Initialization, Player Logic, and Tab Management.
* `js/admin.js`: PIN Security and Master Settings Logic.
* `js/crew.js`: 3D Carousel and Touch-Swipe Engine.
* `js/ads.js`: Pricing calculation and Surcharge Logic.
