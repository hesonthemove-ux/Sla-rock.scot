#!/bin/bash

# 8 Sources covering National/Local Scotland Rock
FEEDS=(
    "https://www.kerrang.com/feed.rss"
    "https://planetrock.com/news/rock-news/feed/"
    "https://punktastic.com/feed/"
    "https://indierockcafe.com/feed/"
    "https://gigradar.uk/feed/"
    "https://www.uncut.co.uk/feed/"
    "https://www.loudersound.com/feeds/all"
    "https://www.metalinjection.net/feed"
)

# Output Directory
NEWS_DIR="/var/www/html/news"
mkdir -p $NEWS_DIR

# Clean out old news
> $NEWS_DIR/national_feed.txt
> $NEWS_DIR/rock.txt
> $NEWS_DIR/metal.txt
> $NEWS_DIR/indie.txt
> $NEWS_DIR/punk.txt
> $NEWS_DIR/alt.txt

# Scrape and Categorize
for url in "${FEEDS[@]}"; do
    raw_news=$(curl -s "$url" | grep -oP '(?<=<title>).*?(?=</title>)' | sed '1d' | sed 's/<!\[CDATA\[//g;s/\]\]>//g')
    
    echo "$raw_news" >> $NEWS_DIR/national_feed.txt

    # Logic to sort into Master Genres
    echo "$raw_news" | while read -r line; do
        low_line=$(echo "$line" | tr '[:upper:]' '[:lower:]')
        if [[ $low_line =~ "metal" || $low_line =~ "slayer" || $low_line =~ "maiden" ]]; then
            echo "$line" >> $NEWS_DIR/metal.txt
        elif [[ $low_line =~ "punk" || $low_line =~ "hardcore" ]]; then
            echo "$line" >> $NEWS_DIR/punk.txt
        elif [[ $low_line =~ "indie" || $low_line =~ "arctic" ]]; then
            echo "$line" >> $NEWS_DIR/indie.txt
        elif [[ $low_line =~ "alt" || $low_line =~ "grunge" ]]; then
            echo "$line" >> $NEWS_DIR/alt.txt
        else
            echo "$line" >> $NEWS_DIR/rock.txt
        fi
    done
done

# Compliance: redistribution hub credit (2026-01-23 Rule)
CREDIT="News sourced from various artists & publications. Rock.Scot is a redistribution hub and not responsible for source content."
for f in $NEWS_DIR/*.txt; do echo -e "\n$CREDIT" >> "$f"; done

chmod 644 $NEWS_DIR/*.txt
